import 'dart:io';
import 'dart:math';

void main() {

  Random random = Random();
  int puan = 0;

  print('BASIC CALCULATOR GAME');
  print('İşlemi çöz, doğru cevabı gir!');

  while(true) {
    int sayi1 = random.nextInt(10) + 1 ;
    int sayi2 = random.nextInt(10) + 1 ;
    List <String> islemler = ["+" , "-" , "/" , "*"];
    String islem = islemler[random.nextInt(islemler.length)];

    double dogruCevap ;
    switch(islem) {
      case "+":
        dogruCevap = sayi1 + sayi2.toDouble();
        break;
      case "-":
        dogruCevap = sayi1 - sayi2.toDouble();
        break;
      case "/":
        sayi2 = random.nextInt(9) + 1; // 0 olmasın diye bu kısım
        dogruCevap = sayi1 / sayi2.toDouble();
        break;
      case "*":
        dogruCevap = sayi1 * sayi2.toDouble();
        break;
      default:
        dogruCevap = 0;
        break;
    }

    print("BAŞLA : ${sayi1} ${islem} ${sayi2} = ?");
    stdout.write("Cevabın");
    String? giris = stdin.readLineSync();

    if(giris == "q"){
      print("OYUNDAN ÇIKTINIZ. İŞTE TOPLAM PUANINIZ: ${puan}");
      break;
    }
 
    double kullanicicevap = double.parse(giris!) ?? -9999;

    if(kullanicicevap == dogruCevap){
      puan += 10;
      print("DOĞRU! Puanın: ${puan}");
    } else {
      print("Yanlış");
    }

  }

}