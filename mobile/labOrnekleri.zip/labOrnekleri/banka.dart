import 'dart:io';

abstract class kredi {
  late String ad;
  late int yas;
  late double gelir;

  kredi(this.ad, this.yas, this.gelir);

  bool onay();

  void KrediBilgileri() {
    print("$ad ($yas), Onay: ${onay() ? 'Onaylandı' : 'Onaylanmadı'}");
  }
}

class BankaA extends kredi {
  BankaA(String ad, int yas, double gelir) : super(ad, yas, gelir);

  @override
  bool onay() {
    return gelir > 40000 && yas > 18 && yas < 24 ? true : false;
  }
}

class BankaB extends kredi {
  BankaB(String ad, int yas, double gelir) : super(ad, yas, gelir);

  @override
  bool onay() {
    return gelir > 80000 && gelir < 100000 && yas > 18 && yas < 30
        ? true
        : false;
  }
}

void main() {
  stdout.write("Ad: ");
  String ad = stdin.readLineSync() ?? '';

  stdout.write("gelir: ");
  double gelir = double.tryParse(stdin.readLineSync()!) ?? 0;

  stdout.write("Yaş: ");
  int yas = int.tryParse(stdin.readLineSync()!) ?? 0;
  while (true) {
    print("$ad, $yas, $gelir");
    print("1- Banka A");
    print("2 - Banka B");
    stdout.write("Seçimin: ");
    int secim = int.tryParse(stdin.readLineSync()!) ?? 0;

    switch (secim) {
      case 1:
        var banka = BankaA(ad, yas, gelir);
        banka.KrediBilgileri();
        banka.onay();
        break;
      case 2:
        var bankab = BankaB(ad, yas, gelir);
        bankab.KrediBilgileri();
        bankab.onay();
        break;
      default:
        break;
    }
    print("Çıkmak için Q basın/ Devam etmek için D.");
    stdout.write("ans: ");
    var ans = stdin.readLineSync() ?? '';

    if (ans.toLowerCase() == 'd') {
      print("Güncellemek istediğiniz bilgi var mı?\n1- Yaş\n2- Gelir");
      stdout.write("Seçim: ");
      var secim = stdin.readLineSync();
      switch (secim) {
        case '1':
          stdout.write("Yaş: ");
          yas = int.tryParse(stdin.readLineSync()!) ?? 0;
          break;
        case '2':
          stdout.write("Gelir: ");
          gelir = double.tryParse(stdin.readLineSync()!) ?? 0;
          break;
      }
      continue;
    } else if (ans.toLowerCase() == 'q') {
      break;
    }
  }
}
