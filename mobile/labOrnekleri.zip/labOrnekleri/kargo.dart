import 'dart:math';

abstract class Kargo {
  String gonderen;
  double agirlik;
  double mesafe;

  Kargo(this.gonderen, this.agirlik, this.mesafe);

  double kargoUcreti();

  void bilgiYazdir(){
    print("$gonderen - Ücret : ${kargoUcreti().toStringAsFixed(2)} TL");
  }
}

class StandartKargo extends Kargo{
  StandartKargo(String gonderen, double agirlik, double mesafe):super(gonderen,agirlik,mesafe);

  @override
  double kargoUcreti(){
    return (agirlik * 0.5) + (mesafe * 1.2);
  }
}

class HizliKargo extends Kargo{
  HizliKargo(String gonderen, double agirlik, double mesafe):super(gonderen,agirlik,mesafe);

  @override
  double kargoUcreti(){
    double ucret = (agirlik * 0.75) + (mesafe * 1.8);
    if(agirlik > 20 || mesafe > 20){
      return ucret +=50;
    }
    return ucret;
  }
}

class UcretsizKargo extends Kargo{
  UcretsizKargo(String gonderen):super(gonderen,0,0);

  @override
  double kargoUcreti(){
    return 0;
  }
}

class Adaylar{
  static final List<String> isimler = [
    'Ali',
    'Ahmet',
    'Zeyd'
  ];

  static String rastgele(){
    final random = Random();
    return isimler[random.nextInt(isimler.length)];
  }
}

void main(){
  String kazanan = Adaylar.rastgele();
  List <Kargo> kargo = [StandartKargo('Tahsin', 61.00, 37.50),
  HizliKargo('Dilara', 58.50, 850.00),
  UcretsizKargo(kazanan)];

  for(var kar in kargo){
    kar.bilgiYazdir();
  } 
}