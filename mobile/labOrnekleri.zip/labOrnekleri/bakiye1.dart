import 'bakiye.dart';

void main(){
  var banka = BankaHesabi('Zeynep', 2500);
  banka.paraCek(200);
  print(banka.bakiye);
  banka.paraYatir(3000);
  print(banka.bakiye);
}