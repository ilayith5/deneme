import 'dart:io';

abstract class Urun {
  String ad;
  double fiyat;

  Urun(this.ad, this.fiyat);

  double fiyatHesapla();

  void UrunInfo() {
    print("$ad: ${fiyatHesapla()}");
  }
}

class Elektronik extends Urun {
  int garanti;
  Elektronik(String ad, double fiyat, this.garanti) : super(ad, fiyat);

  @override
  double fiyatHesapla() {
    return fiyat * 0.8;
  }
}

class Giyim extends Urun {
  String beden;
  Giyim(String ad, double fiyat, this.beden) : super(ad, fiyat);

  @override
  double fiyatHesapla() {
    if (beden.toLowerCase().trim() == 'xl') {
      return fiyat * 0.3;
    } else {
      return fiyat;
    }
  }
}

void main() {
  List<Urun> urunListesi = [];

  while (true) {
    print("Hangi ürünü istiyorsunuz? (Elektronik/Giyim)");
    stdout.write("Seçim: ");
    var secim = stdin.readLineSync() ?? '';

    if(secim == null ||secim.toLowerCase().trim() == 'q'){
        break;
    }

    stdout.write("Ürünün adı: ");
    String ad = stdin.readLineSync() ?? '';

    stdout.write("Fiyat: ");
    double fiyat = double.tryParse(stdin.readLineSync()!) ?? 0;

    switch(secim.toLowerCase()){
        case 'elektronik':
            print("Ürün bilgilerini tamamlayınız:");
            stdout.write("Garanti süresi: ");
            int grnt = int.tryParse(stdin.readLineSync()!) ?? 0;
            urunListesi.add(Elektronik(ad, fiyat, grnt));
            for(var urun in urunListesi){
                urun.UrunInfo();
            }
            break;
        case 'giyim':
            print("Ürün bilgilerini tamamlayınız: ");
            stdout.write("Bedeninizi girin: ");
            String beden = stdin.readLineSync() ?? '';
            urunListesi.add(Giyim(ad, fiyat, beden));
            for(var urun in urunListesi){
                urun.UrunInfo();
            }
            break;
        default:
            break;
    }
  }
}
