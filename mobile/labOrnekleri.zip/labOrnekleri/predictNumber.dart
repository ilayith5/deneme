import 'dart:io' ;
import 'dart:math';

void main(){
  Random random = Random();
  int hedef = random.nextInt(100)+1; 
  int tahmin = -1;

  print("1-100 arasında bir sayı tahmin etmelisin.");

  while(tahmin != hedef){
    stdout.write("Tahmini gir: ");
    tahmin = int.parse(stdin.readLineSync()!);

    if(tahmin < hedef){
      print("Daha büyük bir sayı gir!");
    }else if(tahmin > hedef) {
      print("Daha küçük bir sayı gir'");
    }else {
      print('Doğru tahmin ettin.');
    }


  }




}