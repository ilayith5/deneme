import 'dart:collection';

Map <String, int> kelimeFrekans (String metin) {
  var temizMetin = metin.toLowerCase().replaceAll(RegExp(r'[^\w\s]'), '');
  var kelimeler = temizMetin.split(RegExp(r'\s+'));
  var frekans = <String, int> {};

  for(var kelime in kelimeler){
    frekans[kelime] = (frekans[kelime] ?? 0) + 1 ;
  }

  return frekans;
}

String enCokTekrar(String kelime){
    var frekans = kelimeFrekans(kelime);
    return frekans.entries.reduce((a,b) => a.value > b.value ? a : b).key;

}

void main(){
  String metin = "Dart Flutter için bir backend dilidir. Dart ile tüm sorgular yapılır. Dart ile doğrulama da yapılır. Dart en iyi backend dili.";
  Map <String,int> dict = kelimeFrekans(metin);
  print("En çok tekrar eden kelime : ${enCokTekrar(metin)}");
  dict.forEach((kelime, sayisi) {
    print("${kelime}: ${sayisi}");
  });
}