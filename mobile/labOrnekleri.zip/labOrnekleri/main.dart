import 'dart:collection';

Map<String, int> kelimeFrekansi(String metin) {
  var temizMetin = metin.toLowerCase().replaceAll(RegExp(r'[^\w\s]'), '');
  var kelimeler = temizMetin.split(RegExp(r'\s+'));
  var frekans = <String, int>{};

  for (var kelime in kelimeler) {
    if (kelime.isNotEmpty) {
      frekans[kelime] = (frekans[kelime] ?? 0) + 1;
    }
  }

  return frekans;
}

void main() {
  String metin = "Dart ile Dart backend geliştirmek eğlenceli! Backend öğrenmek güzel, değil mi? Dart çok güçlü!";
  
  var sonuc = kelimeFrekansi(metin);
  
  print("Kelime Frekansları:");
  sonuc.forEach((kelime, adet) {
    print("$kelime: $adet");
  });
}
