class BankaHesabi{
  String _isim;
  double _bakiye;

  BankaHesabi(this._isim , this._bakiye);

  String get isim => _isim;
  double get bakiye => _bakiye;

  void paraYatir(double miktar){
    if(miktar > 0){
      print("Para yatırıldı");
      _bakiye += miktar;
    }
    else{
      print("Negatif bakiye eklenemez");
    }
  }

  void paraCek(double miktar){
    if(miktar <= _bakiye && miktar > 0){
      _bakiye -= miktar;
      print("$miktar para çekildi");
    }else{
      print("Bu miktar çekilemez");
    }
  }

}