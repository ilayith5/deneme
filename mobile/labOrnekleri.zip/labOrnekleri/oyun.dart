abstract class karakter {
  String karakterAdi;
  int seviye;
  karakter(this.karakterAdi, this.seviye);
  void saldiri();
  void yetenek();
}

class Savasci extends karakter {
  Savasci(String karakterAdi, int seviye) : super(karakterAdi, seviye);
  @override
  void saldiri() {
    if (seviye > 3) {
      print("$karakterAdi, geliştirilebilir.");
    } else {
      print("$karakterAdi, $seviye alınabilir.");
    }
  }

  @override
  void yetenek() {
    print("$seviye $karakterAdi daha iyi atış yapar.");
  }
}

class Buyucu extends karakter {
  Buyucu(String karakterAdi, int seviye) : super(karakterAdi, seviye);
  @override
  void saldiri() {
    print("$seviye karakter daha güçlü saldırı yapar.");
  }

  @override
  void yetenek() {
    print("$seviye, $karakterAdi büyü yapma gücüne sahiptir.");
  }
}

class oyuncu {
  String oy;
  karakter kar;
  oyuncu(this.oy, this.kar);
  void oyuncuSaldir() {
    kar.saldiri();
  }

  void OyuncuYetenek() {
    kar.yetenek();
  }

  void compare(oyuncu rakip) {
    if (kar.seviye > rakip.kar.seviye) {
      print("$oyuncu daha güçlü");
    } else if (kar.seviye < rakip.kar.seviye) {
      print("$rakip daha güçlü");
    } else {
      print("Eşit güçte");
    }
  }
}

void main() {
  karakter savasci = Savasci("Abdü", 4);
  karakter buyucu = Buyucu("bilgecan", 5);
  oyuncu g1 = oyuncu("Ali", savasci);
  oyuncu g2 = oyuncu("Samet", buyucu);
  g1.compare(g2);
  g1.oyuncuSaldir();

  g2.OyuncuYetenek();
  savasci.saldiri();
}
