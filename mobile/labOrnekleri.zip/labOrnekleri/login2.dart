import 'dart:io';
import 'dart:async';

Map<String, int> girisDenemeleri = {};
Map<String, Timer> blokeKUllanici = {};

bool KullaniciGiris(String username, String password) {
  const String dogruUsername = 'admin';
  const String dogruSifre = '12345';

  if (blokeKUllanici.containsKey(username)) {
    print("Bu kullanıcı blok edilmiş");
    return false;
  }

  if (username == dogruUsername && password == dogruSifre) {
    print("Giriş başarılı!");
    girisDenemeleri[username] = 0;
    return true;
  } else {
    girisDenemeleri[username] = (girisDenemeleri[username] ?? 0) + 1;
    print("${3 - girisDenemeleri[username]!} hakkınız kaldı");

    if (girisDenemeleri[username]! >= 3) {
      print("Fazla giriş yapıldı. Hesap 30 saniye için bloke ediliyor.");
      blokeKUllanici[username] = Timer(Duration(seconds: 100), () {
        blokeKUllanici.remove(username);
        girisDenemeleri[username] = 0;
      });
    }
    return false;
  }
}

void main() {
  while (true) {
    stdout.write("Kullanıcı Adı: ");
    String? username = stdin.readLineSync();

    stdout.write("Şifreyi girin: ");
    String? password = stdin.readLineSync();

    if (username == null ||
        password == null ||
        username.isEmpty ||
        password.isEmpty) {
      print("Alanları boş bırakamazsınız.");
      continue;
    }

    bool basarili = KullaniciGiris(username, password);
    if (basarili) {
      print("Giriş Başarılı!");
      break;
    }
  }
}
