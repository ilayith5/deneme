--sinema
--create database sinema;
use sinema;

create table filmler (
	film_id int identity(1,1) PRIMARY KEY,
	film_ad nvarchar(100) not null,
	sure float not null,
	tur varchar(25) not null
)

create table salonlar (
	salon_id int PRIMARY KEY identity(1,1) ,
	salon_no nvarchar(20) not null,
	konum varchar(250) not null
)

create table musteriler (
	musteri_id int identity(1,1) PRIMARY KEY,
	ad nvarchar(25) not null,
	soyad nvarchar(25) not null,
	e_posta nvarchar(100) not null
)

create table gosterimler(
	gosterim_id int identity(1,1) PRIMARY KEY,
	film_id int not null,
	salon_id int not null,
	seans varchar(20) not null,
	CONSTRAINT fk_gosterimler_filmid
		FOREIGN KEY (film_id) REFERENCES filmler(film_id),
	CONSTRAINT fk_gosterimler_salonid
		FOREIGN KEY (salon_id) REFERENCES salonlar(salon_id)
)

create table biletler (
	bilet_id int identity(1,1) PRIMARY KEY,
	gosterim_id int not null,
	musteri_id int not null,
	koltuk_no varchar(5) not null,
	fiyat decimal(10,2) not null,
	CONSTRAINT fk_biletler_gosterimid
		FOREIGN KEY (gosterim_id) REFERENCES gosterimler(gosterim_id),
	CONSTRAINT fk_biletler_musteriid
		FOREIGN KEY (musteri_id) REFERENCES musteriler(musteri_id)
)

create table odemeler(
	odeme_id int PRIMARY KEY identity(1,1),
	odeme_tarihi datetime default getdate(),
	tutar float not null,
	odeme_yontemi varchar(20) not null,
	musteri_id int not null,
	bilet_id int not null,

)




