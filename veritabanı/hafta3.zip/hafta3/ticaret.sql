--ticaret

--create database ticaret

use ticaret

create table hesaplar(
	hesap_id int identity(1,1) Primary Key,
	kullanici_adi varchar(50) unique not null,
	parola varchar(50) not null,
	telefon varchar(13) not null,
	adres varchar(50) not null
)
create table musteriler(
	musteri_id int PRIMARY KEY identity(1,1) ,
	ad nvarchar(50) not null,
	soyad nvarchar(50) not null,
	hesap_id int not null,
	CONSTRAINT fk_musteriler_hesapid
		FOREIGN KEY (hesap_id) REFERENCES hesaplar(hesap_id)
)

create table siparisler (
	siparis_id int identity(1,1) PRIMARY KEY,
	siparis_tarihi datetime default getdate(),
	kargo_tarihi date not null,
	toplam_tutar decimal(10,2) not null,
	musteri_id int not null,
	CONSTRAINT fk_siparisler_musteriid
		FOREIGN KEY (musteri_id) REFERENCES musteriler(musteri_id)
) 

create table kategoriler (
	kategori_id int identity(1,1) PRIMARY KEY,
	kategori_adi nvarchar(50) not null
)

create table tedarikciler(
	tedarikci_id int identity(1,1) PRIMARY KEY,
	firma_adi nvarchar(100) not null,
	iletisim nvarchar(13) not null,
	ulke char(2)
)

create table urunler (
	urun_id int identity(1,1) PRIMARY KEY,
	kategori_id int not null,
	tedarikci_id int not null,
	urun_adi varchar(50) not null,
	fiyat float not null,
	stok int not null,
	CONSTRAINT fk_urunler_kategori_id
		FOREIGN KEY (kategori_id) REFERENCES kategoriler(kategori_id),
	CONSTRAINT fk_urunler_tedarikciid
		FOREIGN KEY (tedarikci_id) REFERENCES tedarikciler(tedarikci_id)
)

create table siparis_detaylari (
	siparisd_id int identity(1,1) PRIMARY KEY,
	urun_id int not null,
	adet int not null,
	birim_fiyat decimal(10,2) not null,
	indirim int not null,
	siparis_id int not null,
	CONSTRAINT fk_siparisd_urunid
		FOREIGN KEY (urun_id) REFERENCES urunler(urun_id),
	CONSTRAINT fk_siparisd_siparisid
		FOREIGN KEY (siparis_id) REFERENCES siparisler(siparis_id)
)