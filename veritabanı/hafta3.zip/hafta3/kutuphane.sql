--database olustur
--create database kutup;
use kutup;
--tablolar
create table yazarlar (
	yazar_id int identity(1,1) PRIMARY KEY,
	ad nvarchar(50) not null,
	soyad nvarchar(50) not null,
	dogum_tarihi date
)

create table kitaplar(
	kitap_id int identity(1,1) PRIMARY KEY,
	kitap_adi varchar(100) not null,
	yazar_id int not null,
	basim_tarihi date not null,
	CONSTRAINT fk_kitaplar_yazarid
		FOREIGN KEY (yazar_id) REFERENCES yazarlar(yazar_id)
)

create table uyeler (
	uye_id int identity(1,1) PRIMARY KEY,
	ad nvarchar(50) not null,
	soyad nvarchar(50) not null,
	uye_turu varchar(25) not null,
	telefon nvarchar(13) not null
)

create table odunc_alinan_kitaplar (
	odunc_id int identity(1,1) PRIMARY KEY,
	uye_id int not null,
	kitap_id int not null,
	odunc_tarihi datetime default getdate(),
	teslim_tarihi date not null,
	CONSTRAINT fk_oduncalinank_uyeid
		FOREIGN KEY (uye_id) REFERENCES uyeler(uye_id),
	CONSTRAINT fk_oduncalinank_kitapid
		FOREIGN KEY (kitap_id) REFERENCES kitaplar(kitap_id)
)

create table odeme_islemleri (
	odeme_id int identity(1,1) PRIMARY KEY,
	odunc_id int not null,
	uye_id int not null,
	odeme_tarihi datetime default getdate(),
	tutar float not null,
	CONSTRAINT fk_odeme_oduncid
		FOREIGN KEY (odunc_id) REFERENCES odunc_alinan_kitaplar(odunc_id),
	CONSTRAINT fk_odeme_uyeid
		FOREIGN KEY (uye_id) REFERENCES uyeler(uye_id)
)
