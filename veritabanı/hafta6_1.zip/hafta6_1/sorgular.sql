﻿--backup database HastaneEczaneDB to disk = 'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\Backup\HastaneEczaneDB.bak';

--restore database HastaneEczaneDB from disk = 'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\Backup\HastaneEczaneDB.bak';
use HastaneEczaneDB;

--  Kardiyoloji uzmanı olan doktorları listeleyin.
select *
from Doktorlar as d
where d.UzmanlikAlani = 'Kardiyoloji';

select *
from Doktorlar as d
where d.UzmanlikAlani LIKE '%en';

-- Soyadı "Yılmaz" olan doktorları listeleyin.
select *
from Doktorlar as d
where d.Soyad LIKE 'Yılmaz%';

-- 30 yaşından küçük hastaları listeleyin.
SELECT *
FROM Hastalar as h
where DATEDIFF(year, h.DogumTarihi, GETDATE()) < 30;

select *
from Hastalar as h
where year(getdate()) - year(h.DogumTarihi) < 30;

-- 30 yaşından küçük hastaları cinsiyetlere göre gruplayın.
SELECT h.Cinsiyet, count(h.HastaID) as sayısı
FROM Hastalar as h
where DATEDIFF(year, h.DogumTarihi, GETDATE()) < 30
group by h.Cinsiyet
having count(h.HastaID) > 5

--Adı Mehmet olan doktorları listeleyin.
select *
from Doktorlar as d
where d.Ad NOT LIKE 'Mehmet';

--Adında 'me' olan hastaları listeleyin. 
select *
from Hastalar as h
where h.Ad LIKE '%me%' 

--Kardiyoloji veya Nöroloji alanında uzmanlaşmış doktorları listeleyin.
select *
from Doktorlar as d
where d.UzmanlikAlani = 'Kardiyoloji' or d.UzmanlikAlani = 'Nöroloji';

select *
from Doktorlar as d
where d.UzmanlikAlani NOT IN ('Kardiyoloji', 'Nöroloji');

-- 1990 doğumlu ve sonrası olan hastaları listeleyin.
SELECT *
from Hastalar as h
where year(h.DogumTarihi) >= '1990';

select *
from Hastalar as h
where h.DogumTarihi >= '1990-01-01';

-- Doğum yılı 2000 ve sonrası olan hastaları cinsiyete göre gruplayın.
select h.Cinsiyet, COUNT(h.HastaID)
from Hastalar as h
where h.DogumTarihi >= '2000-01-01'
group by h.Cinsiyet;

-- Soyadında demir geçen eczacıları listeleyin.
select *
from Eczacilar as e
where e.Soyad like '%demir%'

-- Fiyatı 50 TL ile 150 TL arasında olan ilaçları listeleyin.
select *
from Ilaclar as i
where i.Fiyat between 50 and 100;

select *
from Ilaclar as i
where i.Fiyat >50 and i.Fiyat<150

--Kardiyoloji ve Nöroloji dışındaki uzmanlık alanlarına sahip doktorları listeleyin.
select *
from Doktorlar as d
where d.UzmanlikAlani NOT IN ('Kardiyoloji' , 'Nöroloji');


--GROUP BY

-- Her doktorun kaç randevu aldığını listeleyin.
select concat(d.Ad, ' ',d.Soyad) as Doktorlar, count(r.DoktorID) as RandevuSayısı
from Doktorlar as d
inner join Randevular as r on d.DoktorID = r.DoktorID
group by d.Ad, d.Soyad
having COUNT(r.DoktorID) >= 3

-- Her uzmanlık alanına sahip doktor sayısını listeleyin.
select top 1 d.UzmanlikAlani, count(d.DoktorID)
from Doktorlar as d
group by d.UzmanlikAlani

-- En fazla randevu alan doktoru listeleyin.


-- Kardiyoloji ve Nöroloji uzmanı doktorların sayısını listeleyin.
select d.UzmanlikAlani, COUNT(d.Ad)
from Doktorlar as d
where d.UzmanlikAlani = 'kardiyoloji' or d.UzmanlikAlani = 'nöroloji'
group by d.UzmanlikAlani

-- Doğum yılına göre hastaların sayısını gruplayın.
select year(h.DogumTarihi) , count(h.HastaID)
from Hastalar as h
group by year(h.DogumTarihi)

--Her ay yapılan randevuları gruplayın.
select month(r.RandevuTarihi), count(r.RandevuID)
from Randevular as r
group by month(r.RandevuTarihi)

-- eczacılara ait ilaç satışlarının toplam miktarı 35'ten büyük olanları listele.
select concat(e.Ad, ' ', e.Soyad) as Eczacılar, sum(ils.SatisMiktari)
from Eczacilar as e
inner join IlacSatislari as ils on e.EczaciID = ils.EczaciID
group by e.Ad, e.Soyad
having sum(ils.SatisMiktari) > 35

--Çalışma yerlerine göre eczacı sayısını gruplayın.
select e.CalismaYeri, count(e.EczaciID)
from Eczacilar as e
group by e.CalismaYeri

-- Çalışma Yerinde isminde A geçen eczaneleri listeleyin.
select *
from Eczacilar as e
where e.CalismaYeri LIKE 'Eczane A%';

-- İlaçların fiyatlarına göre ortalama satış miktarını gruplayın.
select i.Fiyat, avg(ils.SatisMiktari)
from Ilaclar as i
inner join IlacSatislari as ils on ils.IlacID = i.IlacID
group by i.Fiyat
order by AVG(ils.SatisMiktari) ASC

-- Her ilaç türüne göre toplam satışları gruplayın.
select i.IlacAdi, sum(ils.SatisMiktari)
from Ilaclar as i
inner join IlacSatislari as ils on i.IlacID = ils.IlacID
group by i.IlacAdi

-- Her doktorun aldığı randevuları listeleyin.


-- Her ilaç için yazılan reçeteleri listeleyin.
SELECT i.IlacAdi as IlacAdi, COUNT(r.ReceteId) as ReceteSayisi
FROM ilaclar i
Inner Join ReceteliIlaclar r on i.IlacID= r.IlacID
Group by i.IlacAdi

-- LEFT JOIN

--Tüm doktorları ve varsa aldıkları randevuları listeleyin.
select *
from Doktorlar as d
left join Randevular as r on d.DoktorID = r.DoktorID;

--Tüm hastaları ve varsa aldıkları randevuları listeleyin. 
select * 
from Hastalar as h
left join Randevular as r on h.HastaID = r.RandevuID;

-- Tüm eczacıları ve sattıkları ilaçları listeleyin.
select *
from Eczacilar as e
left join IlacSatislari as ils on e.EczaciID = ils.EczaciID;

--Tüm doktorların yazdığı ilaçların satış miktarlarını listeleyin. 
select d.Ad , d.Soyad, ils.SatisMiktari
from Doktorlar as d
left join Receteler as r on d.DoktorID = r.DoktorID
left join ReceteliIlaclar as ri on ri.ReceteID = r.ReceteID
left join IlacSatislari as ils on ils.IlacID = ri.IlacID;

--RIGHT JOIN

-- Tüm randevuları ve bu randevuları alan hastaları listelemek istiyorum. Eğer bir randevuyu hasta almadıysa, o randevu yine listelensin.
select *
from Hastalar as h
right join Randevular as r on r.HastaID = h.HastaID;

-- Tüm ilaç satışlarını ve bu satışları yapan eczacıları listelemek istiyorum.
select *
from Eczacilar as ils
right join IlacSatislari as e on ils.EczaciID= e.EczaciID;

--Tüm ilaçları ve bu ilaçların yazıldığı reçeteleri listelemek istiyorum.
select *
from Receteler as r
right join ReceteliIlaclar as ri on r.ReceteID = ri.ReceteID
right join Ilaclar as i on i.IlacID = ri.IlacID;

-- FULL OUTER JOIN
--Bu senaryoda, tüm doktorları ve onlara verilen tüm randevuları görmek istiyoruz. 
--Eğer bir doktorun randevusu yoksa, o doktorun bilgileri NULL olarak görünür. 
--Aynı şekilde, bir hasta randevu almış ancak doktoru sistemdeki listede yer almıyorsa, o hasta da NULL ile döner.
select *
from Doktorlar as d
full outer join Randevular as r on r.DoktorID = d.DoktorID
full outer join Hastalar as h on h.HastaID = r.HastaID;

--Bu senaryoda, hastaların aldığı tüm randevuları görmek istiyoruz. 
--Eğer bir hasta herhangi bir randevu almadıysa, hastanın bilgileri görüntülenir, ancak randevu bilgisi NULL olur. 
--Aynı şekilde, bir randevu alınmış ancak hasta bilgisi yoksa, hasta bilgisi de NULL olur.
select *
from Hastalar as h
full outer join Randevular as r on h.HastaID = r.HastaID;

--Bu senaryoda, tüm doktorları ve reçeteye yazdığı ilaçları listelemek istiyoruz.
--Eğer bir doktor hiç ilaç yazmadıysa, IlacAdi ve Fiyat sütunları NULL olur. 
--Aynı şekilde, bir ilaç reçetelenmiş ancak doktor bilgisi yoksa, doktor bilgileri NULL olur.
select *
from Doktorlar as d
full outer join Receteler as r on r.DoktorID =d.DoktorID
full outer join ReceteliIlaclar as ri on ri.ReceteID = r.ReceteID
full outer join Ilaclar as i on i.IlacID = ri.IlacID

-- Bu senaryoda, eczacılara ait ilaç satış bilgilerini görmek istiyoruz.
--Eğer bir eczacı satış yapmadıysa, o eczacının bilgileri NULL olur.
--Aynı şekilde, bir ilaç satılmış ancak eczacı bilgisi yoksa, eczacı bilgileri NULL olur.
select *
from Eczacilar as e
full outer join IlacSatislari as ils on e.EczaciID = ils.EczaciID;

-- UPDATE 

-- Ayşe Kara adlı hastanın doğum tarihini 1990-08-15 olarak güncelle.


--"İç Hastalıkları" alanındaki doktorların uzmanlık alanı artık "Dahiliye" olarak geçecek.


-- “Ayşe Kara” soyadını "Tosun" olarak güncelle.


--"Gabapentin" fiyatı güncellendi: 110.00 → 95.00


-- Çok satan ilacın fiyatı düşürüldü


--En pahalı 5 ilacın fiyatına %15 zam yap

--"Psikiyatri" alanındaki doktorların uzmanlık alanını "Psikiyatri ve Terapi" olarak güncelle


--  Bugün reçete yazan doktorların uzmanlık alanına "(Aktif)" etiketi ekle

-- 50’ten fazla satış yapmış eczacıların adı sonuna “-Başarılı” ekle

-- ALTER 
-- Hastalar tablosuna telefon numarası sütunu ekle


--İlaç fiyatları ondalık olarak girilebilmeli.


-- Eczacılar tablosundaki "CalismaYeri" artık "EczaneAdi" olarak adlandırılmalı


-- İlaçlar barkod numarasıyla takip edilecektir. Barkod bilgisi tekrar edemez.


-- Senaryo – ReceteliIlaclar tablosunda miktar negatif girilebiliyor
--Negatif miktar hatalarını önlemek için bu alana kontrol kısıtı getirilecektir.


--DELETE

--Bugünün tarihinden daha önceki randevular sistem arşivine aktarıldı. Veritabanından silinecekler.


-- Hiç satışı yapılmamış ilaçlar sistemden kaldırılacaktır.

--Hiç reçetesi olmayan hastalar silinecek


--2025 Nisan ayındaki tüm randevular silinecek


-- “Tamsulosin” ilacı iki farklı fiyatla iki kez girilmiş, düşük fiyatlı olan silinecek


--50 kutudan fazla satılan ilaçların geçmiş satış kayıtları silinecek 


--INSERT

-- Tüm “Göz Hastalıkları” hastaları özel göz takip sistemine aktarılacak
