﻿--backup database HastaneEczaneDB to disk = 'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\Backup\HastaneEczaneDB.bak';

restore database HastaneEczaneDB from disk = 'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\Backup\HastaneEczaneDB.bak';
use HastaneEczaneDB;


--  Kardiyoloji uzmanı olan doktorları listeleyin.

-- Soyadı "Yılmaz" olan doktorları listeleyin.

-- 30 yaşından küçük hastaları listeleyin.

-- 30 yaşından küçük hastaları cinsiyetlere göre gruplayın.

--Adı Mehmet olan doktorları listeleyin.

--Adında 'me' olan hastaları listeleyin. 

--Kardiyoloji ve Nöroloji alanında uzmanlaşmış doktorları listeleyin.

-- 1990 doğumlu ve sonrası olan hastaları listeleyin.

-- 2000 dogumlu ve sonrası olan hastaları cinsiyete göre gruplayın.

-- Soyadında demir geçen eczacıları listeleyin.

-- Fiyatı 50 TL ile 150 TL arasında olan ilaçları listeleyin.

--Kardiyoloji ve Nöroloji dışındaki uzmanlık alanlarına sahip doktorları listeleyin.

--GROUP BY

-- Her doktorun kaç randevu aldığını listeleyin.

-- Her uzmanlık alanına sahip doktor sayısını listeleyin.

-- En fazla randevu alan doktoru listeleyin.

-- Kardiyoloji ve Nöroloji uzmanı doktorların sayısını listeleyin.

-- Doğum yılına göre hastaların sayısını gruplayın.

--Her ay yapılan randevuları gruplayın.

-- eczacılara ait ilaç satışlarının toplam miktarı 35'ten büyük olanları listele.

--Çalışma yerlerine göre eczacı sayısını gruplayın.

-- Çalışma Yerinde A geçen eczaneleri listeleyin.

-- İlaçların fiyatlarına göre ortalama satış miktarını gruplayın.


-- Her ilaç türüne göre toplam satışları gruplayın.


-- Her doktorun aldığı randevuları listeleyin.

-- Her ilaç için yazılan reçeteleri listeleyin.


-- LEFT JOIN

--Tüm doktorları ve varsa aldıkları randevuları listeleyin.

--Tüm hastaları ve varsa aldıkları randevuları listeleyin. 


-- Tüm eczacıları ve sattıkları ilaçları listeleyin.


--Tüm doktorların yazdığı ilaçların satış miktarlarını listeleyin. 


--RIGHT JOIN

-- Tüm randevuları ve bu randevuları alan hastaları listelemek istiyorum. Eğer bir randevuyu hasta almadıysa, o randevu yine listelensin.

-- Tüm ilaç satışlarını ve bu satışları yapan eczacıları listelemek istiyorum.


--Tüm ilaçları ve bu ilaçların yazıldığı reçeteleri listelemek istiyorum.


--Tüm ilaç satışlarını ve bunları yazan doktorları listelemek istiyorum. 


-- FULL OUTER JOIN
--Bu senaryoda, tüm doktorları ve onlara verilen tüm randevuları görmek istiyoruz. 
--Eğer bir doktorun randevusu yoksa, o doktorun bilgileri NULL olarak görünür. 
--Aynı şekilde, bir hasta randevu almış ancak doktoru sistemdeki listede yer almıyorsa, o hasta da NULL ile döner.


--Bu senaryoda, hastaların aldığı tüm randevuları görmek istiyoruz. 
--Eğer bir hasta herhangi bir randevu almadıysa, hastanın bilgileri görüntülenir, ancak randevu bilgisi NULL olur. 
--Aynı şekilde, bir randevu alınmış ancak hasta bilgisi yoksa, hasta bilgisi de NULL olur.


--Bu senaryoda, tüm doktorları ve reçeteye yazdığı ilaçları listelemek istiyoruz.
--Eğer bir doktor hiç ilaç yazmadıysa, IlacAdi ve Fiyat sütunları NULL olur. 
--Aynı şekilde, bir ilaç reçetelenmiş ancak doktor bilgisi yoksa, doktor bilgileri NULL olur.


-- Bu senaryoda, eczacılara ait ilaç satış bilgilerini görmek istiyoruz.
--Eğer bir eczacı satış yapmadıysa, o eczacının bilgileri NULL olur.
--Aynı şekilde, bir ilaç satılmış ancak eczacı bilgisi yoksa, eczacı bilgileri NULL olur.


